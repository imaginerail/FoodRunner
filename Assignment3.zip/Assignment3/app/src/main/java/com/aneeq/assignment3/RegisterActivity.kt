package com.aneeq.assignment3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class RegisterActivity : AppCompatActivity() {
    lateinit var etName: EditText
    lateinit var etEmail:EditText
    lateinit var etRegMobileNumber:EditText
    lateinit var etDeliveryAddress:EditText
    lateinit var etRegPassword:EditText
    lateinit var etRegConfirmPassword:EditText
    lateinit var btnRegister:Button
    lateinit var txtArrow:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        title="Registration Page"
        etName=findViewById(R.id.etName)
        etEmail=findViewById(R.id.etEmail)
        etRegMobileNumber=findViewById(R.id.etRegMobileNumber)
        etDeliveryAddress=findViewById(R.id.etDeliveryAddress)
        etRegPassword=findViewById(R.id.etRegPassword)
        etRegConfirmPassword=findViewById(R.id.etRegConfirmPassword)
        btnRegister=findViewById(R.id.btnRegister)
        txtArrow=findViewById(R.id. txtArrow)




        btnRegister.setOnClickListener {
            val name: String = etName.text.toString()
            val email: String = etEmail.text.toString()
            val rgphone: String = etRegMobileNumber.text.toString()
            val rgaddress: String = etDeliveryAddress.text.toString()
            val rgpass: String = etRegPassword.text.toString()
            val rgconpass: String = etRegConfirmPassword.text.toString()
            val check=arrayOf(name,email,rgphone,rgaddress,rgpass,rgconpass)
            //for(i in 0..5){

            //}

            if (rgpass != rgconpass) {
                Toast.makeText(this@RegisterActivity, "Password doesn't match", Toast.LENGTH_LONG)
                    .show()
            } else {

                val intent = Intent(this@RegisterActivity, BufferActivity::class.java)
                intent.putExtra("name", name)
                intent.putExtra("email", email)
                intent.putExtra("rgphone", rgphone)
                intent.putExtra("rgaddress", rgaddress)
                intent.putExtra("rgpass", rgpass)
                intent.putExtra("rgconpass", rgconpass)
                startActivity(intent)

            }
            finish()
        }

        txtArrow.setOnClickListener {
            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()

        }
    }


}
