package com.aneeq.assignment3

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class BufferActivity : AppCompatActivity() {
     lateinit var txtBuffer:TextView
    lateinit var btnBuffer:Button
    lateinit var sharedPreferences: SharedPreferences
    var titleName: String? = "aptx4869"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        sharedPreferences=getSharedPreferences("Food Preferences", Context.MODE_PRIVATE)

        setContentView(R.layout.activity_buffer)

        txtBuffer=findViewById(R.id.txtBuffer)
        btnBuffer=findViewById(R.id.btnBuffer)
        titleName=sharedPreferences.getString("title","Food")
        title = titleName
        txtBuffer.text="You are already Logged in.Welcome back!"
      //login
      /*val phone = intent.getStringExtra("phone")
      val pass=intent.getStringExtra("pass")

       val precheck= arrayOf(phone,pass)
        for(j in 0..1) {
            if (precheck[j] != null) {*/
               // txtBuffer.text = "Login Details:-\nnumber:" + phone + "\nPassword:" + pass

           // }
        //}

        val fpnu = intent.getStringExtra("fpnu")
        val fpemail=intent.getStringExtra("fpemail")

        val postcheck= arrayOf(fpnu,fpemail)
        for(k in 0..1) {
            if (postcheck[k] != null) {
                //txtBuffer.text = fpnu+fpemail
                txtBuffer.text = "Recovery Details:-\nnumber:" +fpnu+ "\nEmail:" +fpemail

            }
        }

        //register
        val name = intent.getStringExtra("name")
        val email = intent.getStringExtra("email")
        val rgphone = intent.getStringExtra("rgphone")
        val rgaddress = intent.getStringExtra("rgaddress")
        val rgpass = intent.getStringExtra("rgpass")
        val rgconpass = intent.getStringExtra("rgconpass")

        val check=arrayOf(name,email,rgphone,rgaddress,rgpass,rgconpass)
        for(i in 0..5){
            if(check[i]!=null){
                txtBuffer.text= "Register Details:- \nname:"+name+"\nemail:"+email+"\nPhone number:"+rgphone+"\nDelivery address:"+rgaddress+"\nPassword:"+rgpass
            }
        }
//forgot password
        btnBuffer.setOnClickListener {
            sharedPreferences.edit().clear().apply()
            val intent = Intent(this@BufferActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

    }


}
