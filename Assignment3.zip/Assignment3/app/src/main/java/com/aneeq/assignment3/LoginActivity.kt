package com.aneeq.assignment3

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    lateinit var txtForgotPassword: TextView
    lateinit var txtSignUp: TextView
    lateinit var btnLogin: Button
    lateinit var etMobileNumber: EditText
    lateinit var etPassword: EditText
    val validNumber="0123456789"
    val validPassword="foodrunner"

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
title="Login Page"





        sharedPreferences=getSharedPreferences("Food Preferences", Context.MODE_PRIVATE)
        var isLoggedIn=sharedPreferences.getBoolean("isLoggedIn",false)
        setContentView(R.layout.activity_login)

        if(isLoggedIn){
            val intent = Intent(this@LoginActivity, BufferActivity::class.java)
            startActivity(intent)
            finish()

        }

        setContentView(R.layout.activity_login)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtSignUp = findViewById(R.id.txtSignUp)
        btnLogin = findViewById(R.id.btnLogin)
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassword)



        txtForgotPassword.setOnClickListener {
            val intent = Intent(this@LoginActivity, ForgotPasswordActivity::class.java)
            startActivity(intent)
        }

        txtSignUp.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }
        btnLogin.setOnClickListener {
            val phone = etMobileNumber.text.toString()
            val pass = etPassword.text.toString()
            var name = "name"
            val intent = Intent(this@LoginActivity, BufferActivity::class.java)
            //intent.putExtra("phone", phone)
            //intent.putExtra("pass", pass)
            if (phone == validNumber && pass==validPassword) {
                name="food"
                savePreferences(name)
                startActivity(intent)
                 finish()
        }
            else{
                Toast.makeText(this@LoginActivity, "invalid", Toast.LENGTH_LONG)
                    .show()
            }
        }

    }

    fun savePreferences(title:String){
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("title",title).apply()

    }
        }


