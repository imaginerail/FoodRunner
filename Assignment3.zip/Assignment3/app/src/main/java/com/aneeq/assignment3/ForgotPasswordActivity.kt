package com.aneeq.assignment3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class ForgotPasswordActivity : AppCompatActivity() {
    lateinit var etFPMobileNumber: EditText
    lateinit var etFPEmail: EditText
    lateinit var btnFPNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        title="Forgot Password Page"

        etFPMobileNumber = findViewById(R.id.etFPMobileNumber)
        etFPEmail = findViewById(R.id.etFPEmail)
        btnFPNext = findViewById(R.id.btnFPNext)

        btnFPNext.setOnClickListener {
            val fpnu: String = etFPMobileNumber.text.toString()
            val fpemail: String = etFPEmail.text.toString()

            val intent = Intent(this@ForgotPasswordActivity, BufferActivity::class.java)
            intent.putExtra("fpnu", fpnu)
            intent.putExtra("fpemail", fpemail)
            startActivity(intent)
            finish()
        }


    }
}
